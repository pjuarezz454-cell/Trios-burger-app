plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace="com.triosburger.app"
    compileSdk=36
    defaultConfig {
        applicationId="com.triosburger.app"
        minSdk=24
        targetSdk=36
        versionCode=3
        versionName="3.0.0"
    }
}
