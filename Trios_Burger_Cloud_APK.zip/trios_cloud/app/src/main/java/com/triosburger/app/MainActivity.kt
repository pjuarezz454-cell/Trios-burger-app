package com.triosburger.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.app.Activity

data class Item(val name:String,val price:Int,var qty:Int=0,val extras:MutableList<String> = mutableListOf())

class MainActivity: AppCompatActivity() {
    val cart=mutableListOf<Item>()
    val products=listOf(
      Item("Super Trios",28), Item("Sencilla",18), Item("Doble Carne",25),
      Item("Hawaiana",25), Item("Mexicana",25), Item("Papas pequeñas",6),
      Item("Papas medianas",8), Item("Papas grandes",12), Item("Nachos grandes",12),
      Item("Crepa de banano",22), Item("Crepa de fresa",22), Item("Crepa mixta",25),
      Item("Mini donas",2)
    )
    lateinit var root: LinearLayout
    val yellow=Color.rgb(255,193,7); val red=Color.rgb(220,35,35); val dark=Color.rgb(15,15,15)
    fun tv(t:String,s:Float=16f,bold:Boolean=false):TextView{
      val v=TextView(this); v.text=t; v.textSize=s; v.setTextColor(Color.WHITE)
      if(bold) v.setTypeface(null,1); v.setPadding(14,8,14,8); return v
    }
    override fun onCreate(b:Bundle?){super.onCreate(b); showHome()}
    fun showHome(){
      root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(dark)
      val scroll=ScrollView(this); val body=LinearLayout(this); body.orientation=LinearLayout.VERTICAL
      val title=tv("TRIOS BURGER",30f,true); title.gravity=Gravity.CENTER; title.setTextColor(yellow); body.addView(title)
      val sub=tv("🔥 SABOR QUE TE CONQUISTA · HECHO AL CARBÓN",14f,true); sub.gravity=Gravity.CENTER; body.addView(sub)
      val img=ImageView(this); img.setImageResource(com.triosburger.app.R.drawable.trios_brand); img.adjustViewBounds=true; body.addView(img)
      val promo=Button(this); promo.text="🔥 OFERTA FIN DE SEMANA · Q25"; body.addView(promo)
      promo.setOnClickListener{add(Item("Combo Fin de Semana",25))}
      for(p in products){
        val row=LinearLayout(this); row.orientation=LinearLayout.HORIZONTAL; row.gravity=Gravity.CENTER_VERTICAL
        val text=tv("${p.name}\nQ${p.price}",17f,true); row.addView(text,LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f))
        val btn=Button(this); btn.text="+ AGREGAR"; row.addView(btn); btn.setOnClickListener{customize(p)}
        body.addView(row)
      }
      val cartBtn=Button(this); cartBtn.text="🛒 CONTINUAR AL CARRITO"; body.addView(cartBtn); cartBtn.setOnClickListener{checkout()}
      scroll.addView(body); root.addView(scroll); setContentView(root)
    }
    fun add(p:Item){cart.add(Item(p.name,p.price,1));Toast.makeText(this,"Agregado: ${p.name}",Toast.LENGTH_SHORT).show()}
    fun customize(p:Item){
      val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL
      val q=EditText(this); q.inputType=2; q.hint="Cantidad"; q.setText("1"); box.addView(q)
      val extras=mutableListOf<String>()
      listOf("Queso +Q3","Tocino +Q5","Huevo +Q3","Extra salsa +Q2").forEach{
        val c=CheckBox(this); c.text=it; box.addView(c); c.setOnCheckedChangeListener{_,on->if(on)extras.add(it)}
      }
      AlertDialog.Builder(this).setTitle(p.name).setView(box).setPositiveButton("Agregar"){_,_->
        val n=q.text.toString().toIntOrNull()?:1; repeat(n){cart.add(Item(p.name,p.price,1,extras.toMutableList()))}
      }.setNegativeButton("Cancelar",null).show()
    }
    fun checkout(){
      val body=LinearLayout(this); body.orientation=LinearLayout.VERTICAL
      val name=EditText(this); name.hint="Nombre completo"; body.addView(name)
      val phone=EditText(this); phone.hint="Teléfono / WhatsApp"; phone.inputType=3; body.addView(phone)
      val address=EditText(this); address.hint="Dirección (si es entrega)"; body.addView(address)
      val type=RadioGroup(this); val pickup=RadioButton(this); pickup.text="Recoger en Trios Burger"; val delivery=RadioButton(this); delivery.text="Servicio a domicilio"; type.addView(pickup);type.addView(delivery);pickup.isChecked=true;body.addView(type)
      val pay=RadioGroup(this); listOf("Efectivo","Transferencia","Tarjeta").forEach{r->val x=RadioButton(this);x.text=r;pay.addView(x)};body.addView(pay)
      AlertDialog.Builder(this).setTitle("🧾 Datos del pedido").setView(body).setPositiveButton("REVISAR PEDIDO"){_,_->confirm(name.text.toString(),phone.text.toString(),address.text.toString(),if(delivery.isChecked)"Entrega" else "Recoger",selected(pay))}
      .setNegativeButton("Cancelar",null).show()
    }
    fun selected(g:RadioGroup):String{val id=g.checkedRadioButtonId; return if(id==-1)"No indicado" else findViewById<RadioButton>(id).text.toString()}
    fun confirm(n:String,ph:String,ad:String,mode:String,pay:String){
      val total=cart.sumOf{it.price}; val lines=cart.groupingBy{it.name}.eachCount().entries.joinToString("\n"){ "${it.value} x ${it.key}" }
      val message="""Hola, Trios Burger! 🍔
Quiero confirmar mi pedido:
$lines

Total: Q$total
Cliente: $n
WhatsApp: $ph
Modalidad: $mode
Dirección: $ad
Pago: $pay
""".trimIndent()
      AlertDialog.Builder(this).setTitle("✅ PEDIDO LISTO").setMessage(message).setPositiveButton("ENVIAR POR WHATSAPP"){_,_->
        val u=Uri.parse("https://wa.me/50257637853?text="+Uri.encode(message));startActivity(Intent(Intent.ACTION_VIEW,u))
      }.setNegativeButton("Volver",null).show()
    }
}