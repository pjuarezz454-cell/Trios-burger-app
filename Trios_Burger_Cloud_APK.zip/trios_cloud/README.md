TRIOS BURGER V3 PREMIUM
======================
Incluye:
- Fotos reales recortadas del material gráfico de Trios Burger aportado anteriormente.
- Identidad visual Trios Burger.
- Selección de extras: queso, tocino, huevo y salsa.
- Cantidades.
- Datos del cliente.
- Recoger o domicilio.
- Método de pago.
- Pantalla de revisión/confirmación.
- Envío del pedido por WhatsApp al 50257637853.
- Android 16 / API 36, minSdk 24.
- applicationId: com.triosburger.app

Nota: para generar el AAB firmado se necesita Android Studio/Gradle y la clave de firma del propietario.
