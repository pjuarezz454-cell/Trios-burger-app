# Trios Burger V3 — APK desde el celular

Este proyecto está preparado para compilar el APK en la nube usando GitHub Actions. No necesitas PC ni Android Studio. GitHub Actions ejecuta Gradle y descarga el APK como artefacto.

## Pasos desde Android

1. Entra a GitHub desde Chrome y crea una cuenta gratuita si no tienes una.
2. Crea un repositorio nuevo, por ejemplo `trios-burger-app`.
3. Descomprime este ZIP en tu teléfono.
4. En GitHub, sube **todo el contenido de esta carpeta**, incluyendo `.github/workflows/build-apk.yml`.
5. En el repositorio entra a **Actions**.
6. Selecciona **Construir APK de Trios Burger** y pulsa **Run workflow**.
7. Espera a que termine el proceso.
8. Abre la ejecución terminada y baja el artefacto **Trios-Burger-APK**.
9. Dentro estará `app-debug.apk`; ese es el archivo que puedes instalar en tu teléfono.

### Nota
El APK debug es apropiado para probar e instalar directamente. Para publicar en Google Play necesitaremos después una firma de lanzamiento y un Android App Bundle (AAB).

## Características incluidas
- Marca Trios Burger y fotografías reales del material proporcionado.
- Menú y promociones.
- Extras: queso, tocino, huevo y salsa.
- Datos del cliente.
- Pedido para recoger o domicilio.
- Pago en efectivo, transferencia o tarjeta.
- Confirmación del pedido.
- Envío del pedido por WhatsApp al 5763 7853.
